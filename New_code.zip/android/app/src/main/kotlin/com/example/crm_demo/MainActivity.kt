package com.onesttech.crm

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
