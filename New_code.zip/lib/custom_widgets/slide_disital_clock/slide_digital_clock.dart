library slide_digital_clock;

export 'package:crm_demo/custom_widgets/slide_disital_clock/src/digital_clock.dart';
export 'package:crm_demo/custom_widgets/slide_disital_clock/src/helpers/clock_model.dart';
